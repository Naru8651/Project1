package com.niit.gadgetcart.dao;

import com.niit.gadgetcart.model.UserOrder;

public interface OrderDAO {
	void addOrder(UserOrder userOrder);
    double getOrderGrandTotal(int cartId);
}

