package com.niit.gadgetcart.util;

public class Util {


		public static String removeComma(String name)
		{
			return name.replace(",", " ");
		}
	}



